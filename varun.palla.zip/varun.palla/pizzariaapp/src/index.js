import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import {BrowserRouter, Route, Switch, Redirect} from 'react-router-dom'
import reportWebVitals from './reportWebVitals';
import Home from './components/Home';
import OrderPizza from './components/OrderPizza';
import BuildUrPizza from './components/BuildUrPizza';
import Login from './components/Login';
import Logout from './components/Logout';
import Register from './components/Register';
import Cart from './components/Cart';


ReactDOM.render(
  <BrowserRouter>
    <App/>
      <Switch>
        <Route exact path="/" render={()=>{
          return(<Redirect to='/Home'/>)
        }}/>
      </Switch>
      <Route exact path='/Home' component={Home}/>
      <Route exact path='/OrderPizza' component={OrderPizza}/>
      <Route exact path='/BuildUrPizza' component={BuildUrPizza}/>
      <Route exact path='/Login' component={Login}/>
      <Route exact path='/Register' component={Register}/>
      <Route exact path='/Cart' component={Cart}/>
      <Route exact path='/Logout' component={Logout}/>
  </BrowserRouter>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
