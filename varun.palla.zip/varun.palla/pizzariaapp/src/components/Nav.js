import React from 'react';
import logo from '../PizzeriaLogo.png'
// import Cart from './components/Cart';
        

class Nav extends React.Component {
    constructor(){
        super()
        // const cookies = new Cookies();
        // this.state={
        //     username:cookies.get('username')
        // }
    }
    render() { 
        return (
        <div style={{borderTop:'1px solid yellow',borderLeft:'1px solid yellow',borderRight:'1px solid yellow'}}>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            &nbsp;
            &nbsp;
                <a class="navbar-brand" href='/home'>Pizzeria</a>
                <a class="navbar-brand" href='/home'>
                    <img src={logo} width="30" height="28" className="d-inline-block align-top" alt="Pizzeria" style={{paddingLeft:'5px'}}/>
                </a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="/OrderPizza">Order Pizza</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/BuildUrPizza">Build Ur Pizza</a>
                        </li>
                        {/* {this.state.username
                                ? 
                                <li class="nav-item"><a class="nav-link" onClick={()=>{        
                                    const cookies = new Cookies();
                                    cookies.remove('username');
                                window.location.reload();}
                            }>Logout</a></li>
                                : <li class="nav-item"><a class="nav-link" href='/Login'>Login</a></li>
                        } */}
                        <li class="nav-item"><a class="nav-link" href='/Login'>Login</a></li>
                        </ul>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarCollapse">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="/Cart" class='btn btn-warning btn-sm' style={{marginRight:'10px'}}>Shopping Cart</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        )
    }
}
 
export default Nav;