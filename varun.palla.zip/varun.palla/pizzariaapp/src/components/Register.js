import React from 'react';
import axios from 'axios';
import {withRouter} from 'react-router-dom'

class Register extends React.Component {
    constructor(){
        super()
        this.state={
            username:'',
            password:'',
            phoneno:'',
            email:''
        }
        this.changeUsername = this.changeUsername.bind(this)
        this.changePassword = this.changePassword.bind(this)
        this.changePhoneno = this.changePhoneno.bind(this)
        this.changeEmail = this.changeEmail.bind(this)
        this.onSubmit= this.onSubmit.bind(this) 
    }
    changeUsername(event){
        this.setState({
            username:event.target.value
        })
    }
    changePassword(event){
        this.setState({
            password:event.target.value
        })
    }
    changePhoneno(event){
        this.setState({
            phoneno:event.target.value
        })
    }
    changeEmail(event){
        this.setState({
            email:event.target.value
        })
    }
    onSubmit(event){
        axios.post('http://localhost:7000/Register',{
            username:this.state.username,
            password:this.state.password,
            phoneno:this.state.phoneno,
            email:this.state.email
        })
            .then((res)=>{
                console.log(res)
            })
            .catch((err)=>{
                console.log(err)
            })
        this.props.history.push('/Login')
    }
    render() { 
        return(
            <div style={{marginLeft:'130px', marginRight:'130px'}}>
                <div style={{width:'55%', margin:'auto'}}>
                    <br/>
                        <h2 align='center'>
                            Registration Form
                        </h2>
                    <br/>
                <form onSubmit={this.onSubmit}>
                    <div class="form-group row">
                        <label for="Username" class="col-sm-3 col-form-label">Username</label>
                        <div class='col-sm-9'>
                            <input type="text" class="form-control" id="Username" placeholder="Enter Username" value={this.state.username} onChange={this.changeUsername} required/>
                        </div>
                    </div>
                    <br/>
                    <div class="form-group row">
                        <label for="Password" class="col-sm-3 col-form-label">Password</label>
                        <div class='col-sm-9'>
                        <input type="password" class="form-control" id="Password" placeholder="Enter Password" value={this.state.password} onChange={this.changePassword} required/>
                        </div>
                    </div>
                    <br/>
                    <div class="form-group row">
                        <label for="Phoneno" class="col-sm-3 col-form-label">Phone Number</label>
                        <div class='col-sm-9'>
                            <input type="text" class="form-control" id="Phoneno" placeholder="Enter Phone Number" value={this.state.phoneno} onChange={this.changePhoneno} required/>
                        </div>
                    </div>
                    <br/>
                    <div class="form-group row">
                        <label for="Email" class="col-sm-3 col-form-label">Email address</label>
                        <div class='col-sm-9'>
                            <input type="email" class="form-control" id="Email" placeholder="Enter email" value={this.state.email} onChange={this.changeEmail} required/>
                        </div>
                    </div>
                    <br/>
                    <center>
                        <button type="submit" class="btn btn-primary" >Register</button>
                    </center>
                </form>
                </div>
            </div>
        );
    }
}
 
export default withRouter(Register);