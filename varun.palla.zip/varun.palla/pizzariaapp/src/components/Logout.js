import React from 'react';
import Cookies from 'universal-cookie';
import {withRouter} from 'react-router-dom'


class Logout extends React.Component {
    constructor(){
        super()
        const cookies = new Cookies();
        cookies.remove('username')
    }
    render() { 
        return(<div>

        </div>)
    }
}
 
export default withRouter(Logout);