import React from 'react';
import axios from 'axios';
import {Link, Redirect,withRouter} from 'react-router-dom'
// import Cookies from 'universal-cookie';
        
class Login extends React.Component {
    constructor(){
        super()
        this.state={
            username:'',
            password:'',
            // ckusername:''
        }
        this.changeUsername = this.changeUsername.bind(this)
        this.changePassword = this.changePassword.bind(this)
        this.onSubmit= this.onSubmit.bind(this) 
    }
    changeUsername(event){
        this.setState({
            username:event.target.value
        })
    }
    changePassword(event){
        this.setState({
            password:event.target.value
        })
    }
    
    onSubmit(event){
        axios.post('http://localhost:7000/Login',{
            username:this.state.username,
            password:this.state.password
        })
            .then((res)=>{
                console.log(res)
            })
            .catch((err)=>{
                console.log(err)
            })
            // const cookies = new Cookies();
            // cookies.set('username', this.state.username, { path: '/' })
            // this.setState({
            //     ckusername:cookies.get('username')
            // })
            
            this.props.history.push("/Cart");
    }
    render() { 
        return(
            <div style={{marginLeft:'130px', marginRight:'130px'}}>
                {/* {this.state.ckusername
                ?
                <div>
                    <h2 align='center'>
                        Logged in Successfully
                    </h2>
                </div>
                :
                <div>
                    <div style={{width:'55%', margin:'auto'}}>
                    <br/>
                    <h2 align='center'>
                        Login Form
                    </h2>
                    <br/>
                <form onSubmit={this.onSubmit}>
                    <div class='form-group row'>
                        <label for="Username" class="col-sm-2 col-form-label">Username </label>
                        <div class='col-sm-9'>
                            <input type="text" class="form-control" id="Username" placeholder="Enter Username" value={this.state.username} onChange={this.changeUsername} required/>
                        </div>
                    </div>
                    <br/>
                    <div class="form-group row">
                        <label for="Password" class="col-sm-2 col-form-label">Password  </label>
                        <div class='col-sm-9'>
                            <input type="password" class="form-control" id="Password" placeholder="Enter Password" value={this.state.password} onChange={this.changePassword} required/>
                        </div>
                    </div>
                    <br/>
                    <center>
                        <button type="submit" class="btn btn-primary btn-xs" >Login</button>
                    </center>
                </form>
                <div>
                    For New User <Link to='/Register'>Registration </Link> 
                </div>
                </div>
                </div>
                } */}
                <div>
                    <div style={{width:'55%', margin:'auto'}}>
                    <br/>
                    <h2 align='center'>
                        Login Form
                    </h2>
                    <br/>
                <form onSubmit={this.onSubmit}>
                    <div class='form-group row'>
                        <label for="Username" class="col-sm-2 col-form-label">Username </label>
                        <div class='col-sm-9'>
                            <input type="text" class="form-control" id="Username" placeholder="Enter Username" value={this.state.username} onChange={this.changeUsername} required/>
                        </div>
                    </div>
                    <br/>
                    <div class="form-group row">
                        <label for="Password" class="col-sm-2 col-form-label">Password  </label>
                        <div class='col-sm-9'>
                            <input type="password" class="form-control" id="Password" placeholder="Enter Password" value={this.state.password} onChange={this.changePassword} required/>
                        </div>
                    </div>
                    <br/>
                    <center>
                        <button type="submit" class="btn btn-primary btn-xs" >Login</button>
                    </center>
                </form>
                <div>
                    For New User <Link to='/Register'>Registration </Link> 
                </div>
                </div>
                </div>
            </div>
        );
    }
}
 
export default withRouter(Login);

