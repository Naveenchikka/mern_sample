import React from 'react';
import axios from 'axios';
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';

class OrderPizza extends React.Component {
    constructor(){
        super()
        this.state={
            pizzas : []
        }
    }
    onCartClick(pizza){
        axios.post("http://localhost:7000/Cart",{
            ...pizza,
            'quantity':1
        })
            .then((responce)=>{
                console.log(responce)
            })
            .catch((err)=>{
                console.log(err)
            })
    }
    componentDidMount(){
        axios.get("http://localhost:7000/OrderPizza")
            .then((responce)=>{
                this.setState({
                    pizzas:responce.data
                })
            })
            .catch((err)=>{
                console.log(err)
            })
    }
    render(){
        var output=this.state.pizzas.map((pizza)=>{
            return(
                <div class="card" style={{display:'inline-block', width:'46%', height:'270px',marginRight:'2%',marginLeft:'2%', marginTop:'1.5%',marginBottom:'1.5%', border:'1px solid black'}}>
                    <div style={{marginLeft:'10px', marginTop:'3px', marginRight:'10px',marginBottom:'3px'}}>
                    <Row>
                        <Col xs={3}>
                            <center>
                            <h5 class="card-title">{pizza.name}</h5>
                            </center> 
                            <br/>
                            <center>
                            <div style={{height:"20px",width:"20px",backgroundColor:(pizza.type=="veg")?"green":"red"}}></div>
                            </center>
                            <br/>
                            <center>
                                <h5 class="card-title">
                                    &#x20b9;{pizza.price}.00
                                </h5>
                            </center>
                        </Col>
                        <Col xs={6}>
                            <p class='card-text' style={{textAlign:'left'}}>{pizza.description}</p>
                            <p class='card-text' style={{textAlign:'left'}}>
                                <b>Ingredients: </b>{pizza.ingredients+' '}
                            </p>
                            <p class='card-text' style={{textAlign:'left'}}>
                                <b>Toppings: </b>{pizza.topping+' '}
                            </p>
                        </Col>
                        <Col xs={3}>
                            <img class="card-img-top" src={pizza.image} alt=""/>
                            <br/>
                            <br/>
                            <center>
                                <button class='btn btn-warning btn-sm' onClick={()=>this.onCartClick(pizza)}>Add to Cart
                                </button>
                            </center>
                        </Col>    
                    </Row>
                    </div>
                </div>
            )
        })
        return(<div>
            <div style={{ marginLeft: '130px', marginRight: '130px',border: '1px solid yellow'}}>
                <div>
                    {output}
                </div>
            </div>
            <div style={{textAlign:'center',color: 'orange', fontSize: '12px'}}>
                <i>Copyrights @ 2017 Pizzeria - All rights reserved</i> 
            </div>
        </div>
        )
    }
}

export default OrderPizza;