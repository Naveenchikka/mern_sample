import React from 'react';
import axios from 'axios';
import { Row, Toast } from 'react-bootstrap';
import { Col } from 'react-bootstrap';

// import {withRouter} from 'react-router-dom'


class Cart extends React.Component {
    constructor(){
        super()
        this.state={
            data:[],
            ingData:[]
        }
    }
    
    componentDidMount(){
        axios.get('http://localhost:7000/Cart')
            .then((res)=>{
                this.setState({
                    data:res.data                    
                })
            })
            .catch((err)=>{
                console.log(err)
            }
        )
        axios.get('http://localhost:7000/IngData')
            .then((res)=>{
                this.setState({
                    ingData:res.data                    
                })
            })
            .catch((err)=>{
                console.log(err)
            }
        )    
    }
    onAddClick(pizza){
        axios.post("http://localhost:7000/AddCart",{
            ...pizza        
        })
            .then((responce)=>{
                console.log(responce)
            })
            .catch((err)=>{
                console.log(err)
            })
        window.location.reload();
    }
    onDelClick(pizza){
        axios.post("http://localhost:7000/DelCart",{
            ...pizza        
        })
            .then((responce)=>{
                console.log(responce)
            })
            .catch((err)=>{
                console.log(err)
            })
        // this.componentDidMount()
        window.location.reload();
    }
    
    componentWillUpdate(){
        // window.location.reload();
        // this.componentDidMount();   
    }
    
    render() { 
        var total=0
        var total1=0
        var output2=this.state.ingData.map((i,index)=>{
            total1=total1+(i.total)
            return(
                <div key={index} class='Card' style={{ width:'84%',height:'40px',marginRight:'8%',marginLeft:'8%', marginTop:'1%',marginBottom:'2%', border:'1px solid black'}}>
                    <div class='mx-2'>
                        <Row>
                            <Col>
                                Ingrediants Data : {i.ingData.join(', ')}
                            </Col>
                            <Col>
                                Price:{i.total}
                            </Col>
                        </Row>
                    </div>
                </div>
            )
        })
        var output = this.state.data.map((d, index)=>{
            total=total+(d.price)*(d.quantity)
            return(
                <div key={index} class='Card' style={{ width:'84%',height:'220px',marginRight:'8%',marginLeft:'8%', marginTop:'1%',marginBottom:'2%', border:'1px solid black'}}>
                    <div>
                        <Row style={{margin:'2px'}} >
                            <Col xs={3}>
                                <br/>
                            <center>
                                <h5 class="card-title">{d.name}</h5>
                            </center> 
                            <br/>
                            <center>
                                <div style={{height:"20px",width:"20px",backgroundColor:(d.type=="veg")?"green":"red"}}></div>
                            </center>
                            <br/>
                            <center>
                                <h5 class="card-title">
                                    &#x20b9;{d.price}.00
                                </h5>
                            </center>
                            </Col>
                            <Col xs={6}>
                                <br/>
                                <p class='card-text' style={{textAlign:'left'}}>{d.description}</p>
                                <p class='card-text' style={{textAlign:'left'}}>
                                    <b>Ingredients: </b>{d.ingredients+' '}
                                </p>
                                <p class='card-text' style={{textAlign:'left'}}>
                                    <b>Toppings: </b>{d.topping+' '}
                                </p>
                                <br/>
                            </Col>
                            <Col xs={3}>
                                <br/>
                                <img class="card-img-top" src={d.image} alt="" style={{weight:'40px', height:'100px'}}/>
                                <br/>
                                <br/>
                                <center>
                                    <button class='btn btn-success btn-sm' onClick={()=>this.onAddClick(d)}>Add</button>&nbsp;&nbsp;{d.quantity}&nbsp;&nbsp; 
                                    <button class='btn btn-danger btn-sm' onClick={()=>this.onDelClick(d)}>Delete</button>
                                </center>
                            </Col>
                        </Row>
                    </div>
                </div>
            )
        })
        
        return(<div>
            <div style={{ marginLeft: '130px', marginRight: '130px',border: '1px solid yellow'}}>
                <div style={{textAlign:'center'}}>
                    Shopping Cart
                </div>
                <div>
                    {output}
                </div>
                <div>
                    {output2}
                </div>
                
                <div style={{textAlign:'center',color: 'black', fontSize: '18px'}}>
                    Total = {total+total1}
                    {/* + this.props.total} */}
                </div>
            </div>
            <div style={{textAlign:'center',color: 'orange', fontSize: '12px'}}>
                <i>Copyrights @ 2017 Pizzeria - All rights reserved</i> 
            </div>
            </div>
        );
    }
}
 
export default Cart;