import React from 'react';
import './Home.css'
import ingredients from '../ingredients.jpg'
import chef from '../Chef.jpg'
import time from '../time.png'
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
class Home extends React.Component {
    render() { 
        return (<div>
                <div  className='Home'>
                    <Row>
                        <Col className='Home-Heading'>
                            <h2>
                                Our story
                            </h2>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                        <div className='Home-Body'>
                            <p>
                                We believe in good.We launched Fresh Pan Best Excuse Awards on our Facebook fan page. Fans were situations they had to come up with wacky and fun excuses.The person with best excuse won the Best excuse Badge and won Pizzeria's vouchers. Their enthusiastic response proved that Pizzeria's Fresh pan Pizza is the Tastiest Pan Pizza Ever!
                            </p>
                            <p>
                                Ever since we launched the Tastiest pan Pizza, ever people have not been able to resist the softest, cheesiest, crunchiest, buttersit Domino's Fresh Pan Pizza. They have been leaving the stage in the middle of a performance and even finding excuses to disqualified in a football match.
                            </p>
                            <p>
                                We launched Fresh Pan Pizza Best Excuse Awards on our Facebook fan page. Fans were given situations where they had to come up with wacky and fun excuses. The person with best excuse won the Best Excuse badge and won Domino's vouchers.Their enthusiastic respsonse provided that Pizzeria's fresh Pan Pizza is the Tastiest Pan Pizza. Ever!
                            </p>
                        </div>
                        </Col>
                    </Row>
                    <Row>
                        <Col sm={5}><img src={ingredients} alt='' className="ImgIngrediants" /></Col>
                        <Col>
                            <div>
                                <br/>
                                <br/>
                                <h3 className='Ingrediants'>
                                    Ingredients
                                </h3>
                                <p className = "Ingrediants">
                                    We're ruthless about goodness.We have no qualms about tearing up a day-old lettuce leaf(straight from the farm), or steaming baby(carrot).Cut.Cut.Chop.Chop.Steam.Steam.Stir Stir. While they're still young and fresh-that's our motto.It makes the kitchen a better place.
                                </p>
                            </div>
                        </Col>
                    </Row>
                    <Row>
                        <Col xs={7}>
                            <div>
                                <br/>
                                <br/>
                                <h3 className='Chef'>
                                    Our Chefs
                                </h3>
                                <p className = "Chef">
                                    They make sauces sing and salads dance They create magic with skill, knowledge, passion, and stirring spoons (among other things). They make goodness so good, it doesn't know what to do with itself. We do though. We send it to you.
                                </p>
                            </div>
                        </Col>
                        <Col>
                            <img src={chef} className="ImgChef"/>
                        </Col>
                    </Row>  
                    <Row>
                        <Col>
                            <img src={time} className="ImgTime"/>
                        </Col>
                        <Col>
                            <div>
                                <br/>
                                <br/>
                                <br/>
                                <h3 className='Time'>
                                    45 min delivery
                                </h3>
                            </div>
                        </Col>
                    </Row>
                </div>
                <div className='Home-Footer'>
                    <i>Copyrights @ 2017 Pizzeria - All rights reserved</i> 
                </div>
        </div>);
    }
}
 
export default Home;