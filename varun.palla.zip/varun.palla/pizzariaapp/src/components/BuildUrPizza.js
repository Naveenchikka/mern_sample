import React from 'react';
import './BuildUrPizza.css'
import axios from 'axios';
// import Cart from './Cart';

class BuildUrPizza extends React.Component {
    constructor(){
        super()
        this.state={
            data:[],
            total:0,
            checkData:[],
            ingData:[]
        }
        
    }
    changeCheckData(data){
        this.setState({
            checkData:data
        })
    }
    changeTotal(price){
        this.setState({
            total:price
        })
    }

    buildClick(){
        axios.post('http://localhost:7000/IngData',{
            ingData:this.state.ingData,
            total:this.state.total
        })
        .then((res)=>{
            console.log(res)
        })
        .catch((err)=>{
            console.log(err)
        })
    }

    onHandle=(pos)=>{
        const updated = this.state.checkData.map((item, index) =>
        index === pos ? !item : item
      );
  
      this.changeCheckData(updated);
        const tenparr=[]
      const totalPrice = updated.reduce(
        (sum, currentState, index) => {
          if (currentState === true) {
            tenparr.push(this.state.data[index].tname)
            return sum + this.state.data[index].price;
          }
          return sum;
        },
        0
      );
      console.log(tenparr)
        this.setState({
            ingData:tenparr
        })
      this.changeTotal(totalPrice);
    }
    componentDidMount(){
        axios.get('http://localhost:7000/Ingredients')
            .then((res)=>{
                this.setState({
                    data:res.data
                })
                var temp = []
                for(let i =0;i< this.state.data.length;i++){
                    temp.push(false)  
                }
                this.setState({
                    checkData:temp
                })
            })
            .catch((err)=>{
                console.log(err)
            })
    }
    render() {
        var output = this.state.data.map((d, index)=>{
            return (
                <tr>
                    <td><img src={d.image} style={{height:'30px', width:'30px'}}/></td>
                    <td>{d.tname}&nbsp; &nbsp;&#x20b9;{d.price}.00</td>
                    <td><input type='checkbox' checked={this.state.checkData[index]} onChange={()=>{this.onHandle(index)}}/>&nbsp;Add</td>
                </tr>
            )
        }) 
        return (
        <div>
            {/* <div style={{display:'none'}}><Cart total={this.state.total}/></div> */}
            <div className='BuildUrPizza'>
                <i>Pizzeria now gives you options to build your pizza, Customize your pizza by choosing ingrediants from the list given below..</i>
                <br/>
                <br/>
                <div>
                    <table class="table table-bordered" style={{marginRight:'15%',marginLeft:'15%', width:'70%'}}>
                        <tbody>
                            {output}
                        </tbody>
                    </table>
                    <div>
                        <div>
                            Total Cost:{this.state.total}
                        </div>
                        <br/>
                        <button class='btn btn-sm' style={{color:'orange', backgroundColor:'black', border:'1px solid orange'}} onClick={()=>{this.buildClick()}}>Build Ur Pizza</button>
                        <br/>
                        <br/>
                    </div>
                </div>
            </div>
            <div style={{textAlign:'center',color: 'orange', fontSize: '12px'}}>
                <i>Copyrights @ 2017 Pizzeria - All rights reserved</i> 
        </div>
    </div>
    );
    }
}
 
export default BuildUrPizza;