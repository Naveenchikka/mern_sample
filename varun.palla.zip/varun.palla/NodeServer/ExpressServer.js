const express = require('express')
const CORS = require('cors')
var mongodb = require('mongodb')

var dbClient = mongodb.MongoClient
var url = 'mongodb://localhost:27017'

const server = express()
server.use(CORS({credentials: true, origin: 'http://localhost:3000'}))
server.use(express.json())  
server.use(express.urlencoded({extended:true}))
var db
dbClient.connect(url,(err,client)=>{
    if(err){
        console.log("Error occured during the connection");
    }
    else{
        db = client.db('Pizzeria')
    }
})

server.get('/OrderPizza',(req,res)=>{
    db.collection('PizzaCatelog').find({}).toArray((err,data)=>{
        res.send(data);
        res.end()     
    })
})

server.get('/Ingredients',(req, res)=>{
    db.collection('Ingredients').find({}).toArray((err, data)=>{
        res.send(data)
        res.end()
    })
})

server.post('/IngData',(req,res)=>{
    db.collection('IngData').insertOne(req.body)
})

server.get('/IngData',(req, res)=>{
    db.collection('IngData').find({}).toArray((err, data)=>{
        res.send(data)
        res.end()
    })
})

server.get('/Cart',(req, res)=>{
    db.collection('Cart').find({}).toArray((err, data)=>{
        res.send(data)
        res.end()
    })
})

server.post('/Cart',(req,res)=>{
    collection = db.collection('Cart')
    // collection.insertOne(req.body)
    let data = req.body
    collection.find({'name':data['name']}).toArray((err, d)=>{
        if(d.length==0){
            collection.insertOne(req.body)
        }
        else{
            let q = d[0]['quantity']+1
            // let p = d[0]['price']*q
            collection.updateOne({'name':data['name']},{$set:{'quantity':q}})
        }
    })
})

server.post('/AddCart',(req,res)=>{
    collection = db.collection('Cart')
    let data = req.body
    collection.find({'name':data['name']}).toArray((err, d)=>{
        let q = d[0]['quantity']+1
        // let p = d[0]['price']*q
        collection.updateOne({'name':data['name']},{$set:{'quantity':q}})
    })
})

server.post('/DelCart',(req,res)=>{
    collection = db.collection('Cart')
    let data = req.body
    collection.find({'name':data['name']}).toArray((err, d)=>{
        if(d[0]['quantity']==1){
            collection.deleteOne(req.body)
        }
        else{
            let q = d[0]['quantity']-1
            // let p = d[0]['price']*q
            collection.updateOne({'name':data['name']},{$set:{'quantity':q}})
        }
    })
})

server.post('/Register',(req,res)=>{
    // data={
    //     'username':'varun',
    //     'password':'Varun@457',
    //     'email':'pallavarun457@gmail.com'
    //     'phoneno':'8179421384'
    // }
    db.collection('Users').insertOne(req.body)
    console.log(req.body)
})

server.post('/Login',(req,res)=>{
    collection = db.collection('Users')
    if(collection.find(req.body)){
        console.log("Logged in Successfully");
    }
    else{
        console.log("U need to register first")
    }
})

server.listen(7000,()=>{
    console.log("Created Server at port 7000");
})